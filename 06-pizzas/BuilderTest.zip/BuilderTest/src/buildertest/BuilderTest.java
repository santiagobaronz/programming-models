/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package buildertest;

import Director.Cocina;
import Builder.HawaiPizzaBuilder;
import Builder.PicantePizzaBuilder;
import Builder.PizzaBuilder;
import Producto.Pizza;

/**
 *
 * @author Estudiantes
 */
public class BuilderTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cocina cocina = new Cocina();
        PizzaBuilder objHawaiPizzaBuilder = new HawaiPizzaBuilder();
        PizzaBuilder objPicantePizzaBuilder = new PicantePizzaBuilder();
        
        cocina.setPizzaBuilder(objHawaiPizzaBuilder);
        cocina.construirPizza();
        Pizza pizza = cocina.getPizza();
    }
    
}
