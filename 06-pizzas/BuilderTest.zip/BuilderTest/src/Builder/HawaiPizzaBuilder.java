/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Builder;

import Producto.Pizza;

/**
 *
 * @author Estudiantes
 */
public class HawaiPizzaBuilder extends PizzaBuilder {
    
    public HawaiPizzaBuilder(){
        super.pizza = new Pizza();
    }
    
    public void buildMasa() { 
        pizza.setMasa("suave"); 
    }
    
    public void buildSalsa() { 
        pizza.setSalsa("dulce"); 
    }
    
    public void buildRelleno() { 
        pizza.setRelleno("chorizo+alcachofas");
    }
    
}
